package kr.ac.kopo.yes.controller;



import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import java.util.List;
import java.util.Locale;


import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;


import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.FreeBoard;
import kr.ac.kopo.yes.model.PageMaker;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;
import kr.ac.kopo.yes.model.User;
import kr.ac.kopo.yes.service.FreeBoardService;

@Controller
@RequestMapping(value= "/FreeBoard")
public class FreeBoardController {
	final String path = "FreeBoard/";
	ArrayList<String> list;
	
	
	private static final Logger logger = LoggerFactory.getLogger(FreeBoardController.class);
	
	@Autowired
	FreeBoardService FS; // FreeBoardService FS; = new FreeBoardService();
	
	
	//final String uploadPath = "D:\\images";
	/*@Resource(name = "uploadPath")
	private String uploadPath;
	*/
	/**
	 * �옄�쑀寃뚯떆�뙋 紐⑸줉
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/list")
	String list(Model model) {
		List<FreeBoard> list = FS.list();
		model.addAttribute("list", list);
	
		return path+"list";
	}
	


	/**
	 * �옄�쑀寃뚯떆�뙋 �벑濡� �뤌
	 * @param locale
	 * @param model
	 * @return
	 */
	
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	String add(Locale locale, Model model) {
		
		return path+"add";
	}

	
	//게시글올리기 & 파일업로드
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String add(HttpSession session, MultipartHttpServletRequest mtfRequest,FreeBoard item,FileUpload fileup) throws Exception {
		item.setId((String) session.getAttribute("user"));
		FS.add(item);
		List<MultipartFile> fileList = mtfRequest.getFiles("file");	
		//String src = mtfRequest.getParameter("src");
        //System.out.println("src value : " + src);

        //String path = "/Users/apple/Documents/image/";
		String path = "C:\\images\\imgUpload\\";
 
	        for (MultipartFile mf : fileList) {
	            String originFileName = mf.getOriginalFilename(); // 원본파일명
	            long fileSize = mf.getSize(); // 파일 사이즈
	            
	            System.out.println("originFileName : " + originFileName);
	            System.out.println("fileSize : " + fileSize);
	            //String saveFile =originFileName;
	            
	            String saveFile = System.currentTimeMillis() +originFileName;
	            
	            String safeFile = path + System.currentTimeMillis() + originFileName;
	           // String safeFile = path + System.currentTimeMillis() + originFileName;
	            try {
	                mf.transferTo(new File(safeFile));
	            } catch (IllegalStateException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            } catch (IOException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	            FS.fileadd(saveFile);
	        }
	        
	        return "redirect:list";
	}
	
	@RequestMapping(value="/update", method=RequestMethod.GET)
	String update(int fb_num, Model model){
	FreeBoard item = FS.item(fb_num);
	model.addAttribute("item",item);
	
	//사진보여주기
		List<FileUpload> filevi = FS.filevi(fb_num);
		model.addAttribute("filevi", filevi);
			
		return path+"update";
	}
	
	@RequestMapping("/deleteFile")
	String deleteFile(String fileName,int fb_num) {
		
		
		FS.filedelete(fileName);

		return "redirect:update?fb_num=" + fb_num;
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	String update(MultipartHttpServletRequest mtfRequest,FreeBoard item,FileUpload fileup,int fb_num) throws Exception{
		FS.update(item);
		
		logger.info(fb_num+"fb_num");
		List<MultipartFile> fileList = mtfRequest.getFiles("file");
		
		String path = "C:\\images\\imgUpload\\";
	        
		for (MultipartFile mf : fileList) {
            String originFileName = mf.getOriginalFilename(); // 원본파일명
            long fileSize = mf.getSize(); // 파일 사이즈
            
            System.out.println("originFileName : " + originFileName);
            System.out.println("fileSize : " + fileSize);

            String saveFile = System.currentTimeMillis() +originFileName;
            String safeFile = path + System.currentTimeMillis() + originFileName;
           System.out.println(saveFile+"saveFile");
            // String safeFile = path + System.currentTimeMillis() + originFileName;
            try {
                mf.transferTo(new File(safeFile));
            } catch (IllegalStateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            fileup.setFb_num(fb_num);
            fileup.setFile_name(saveFile);
            logger.info(saveFile+"saveFile");
            FS.fileupdate(fileup);
        }
		
		return "redirect:list";
	}	
	/*@RequestMapping(value="/update", method=RequestMethod.POST)
	String update(HttpSession session,MultipartHttpServletRequest mtfRequest,
			@RequestParam("thumb") String thumb,
			@RequestParam("fb_title") String fb_title,
			@RequestParam("fb_contents") String fb_contents
			) throws Exception{
		
		List<MultipartFile> fileList = mtfRequest.getFiles("file");
		HashMap<Object,Object> map = new HashMap<Object,Object>();
		map.put("thumb", thumb);
		map.put("fb_title", fb_title);
		map.put("fb_contents", fb_contents);
		
	    FS.update(map);	
		
		 	String safeFile=null;
	        String imgUploadPath = uploadPath;
	        
	        for (MultipartFile mf : fileList) {
	            String originFileName = mf.getOriginalFilename(); // �썝蹂� �뙆�씪 紐�
	           
	            System.out.println("originFileName : " + originFileName);

	            safeFile = originFileName;
	            String saveFile = imgUploadPath + File.separator + safeFile;
	            map.put("file", safeFile);
	            
	            try {
	                mf.transferTo(new File(saveFile));
	            } catch (IllegalStateException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	            //item.setFile(saveFile);
	            FS.fileupdate(map);
	        }
	
		return "redirect:list";
	}	*/
	
	@RequestMapping("/delete")
	String delete(int fb_num) {
		
		
		FS.delete(fb_num);

		return "redirect:list";
	}

	
	//게시글
	@RequestMapping(value="/view")
	String view(int fb_num, Model model) {
		//조회수
		FS.incView(fb_num);
		/*FileUpload filevi = FUS.filevi(fb_num);
		model.addAttribute("filelist", filevi);
		*/
		
		//게시글보여주기 관련
		FreeBoard item = FS.item(fb_num);
		model.addAttribute("item", item);
		
		//사진보여주기
		List<FileUpload> filevi = FS.filevi(fb_num);
		model.addAttribute("filevi", filevi);
				
		
		List<Reply> reply = FS.replyList(fb_num);
		model.addAttribute("reply", reply);
		
		return path + "view";
	}
	
	
/*	@ResponseBody
	@RequestMapping(value = "/imageView", method = RequestMethod.GET)
	public byte[] getImageAsByteArray(HttpServletResponse response, Model model) throws Exception {
		
		String path = "C:\\images\\imgUpload\\";
		
		
		//file테이블의 file을 가져와야됨
		File fileup= new File(path);
		InputStream in = new FileInputStream(fileup);
		
		return IOUtils.toByteArray(in);
	} 
*/

	@RequestMapping("/like")
	String like(int fb_num) {
		FS.like(fb_num);
		return "redirect:list";
	}


	
	// 댓글목록
		/*//�뙎湲��옉�꽦
	@RequestMapping(value="/view",method=RequestMethod.POST)
	String addReply(Reply reply,HttpSession session) throws Exception{
		
		
		reply.setReply_id((String) session.getAttribute("user"));
		//reply.setReply_fb_num((Integer) session.getAttribute("freeboard"));
		
		FS.addReply(reply);
		
		return "redirect:/FreeBoard/view?fb_num=" + reply.getReply_fb_num();
	
	}
	*/

	@ResponseBody
	@RequestMapping(value = "/view/replyList", method = RequestMethod.GET)
	public List<Reply> getReplyList(@RequestParam("n") int fb_num) throws Exception {
		logger.info("get reply list");
	 List<Reply> reply = FS.replyList(fb_num);
	 
	 return reply;
	} 
	//댓글추가
	@ResponseBody
	@RequestMapping(value="/view/addReply",method=RequestMethod.POST)
	public void addReply(Reply reply,HttpSession session) throws Exception{
		// logger.info("regist reply");
		
		reply.setId((String) session.getAttribute("user"));
		
		FS.addReply(reply);
		}

	
	
	
	// 댓글지우기
	@ResponseBody
	@RequestMapping(value = "/view/deleteReply", method = RequestMethod.POST)
	public int getReplyList(Reply reply,HttpSession session,User member) throws Exception {
	 logger.info("post delete reply");

	 int result = 0;
	 
	 member.setId((String)session.getAttribute("user"));
	   System.out.println(reply.getReply_num()+"<<<<<<<<<<<<getReply_num");
	 String replyId = FS.idCheck(reply.getReply_num());
	 
	 if(member.getId().equals(replyId)) {
	  
	  reply.setId(member.getId());
	  FS.deleteReply(reply);
	  
	  result = 1;
	 }
	 
	 return result; 
	}
	
	// 게시목록+ 페이징
	@RequestMapping(value = "/listPage", method = RequestMethod.GET)
	public void listPage(Criteria cri, Model model) throws Exception {
	 logger.info("get list search");
	 
	 List<FreeBoard> list = FS.listPage(cri);
	 model.addAttribute("list", list);
	
	 PageMaker pageMaker = new PageMaker();
	 pageMaker.setCri(cri);
	 pageMaker.setTotalCount(FS.listCount());
	 model.addAttribute("pageMaker", pageMaker);
	}
	
	// 게시판+ 페이징+ 검색
	@RequestMapping(value = "/listSearch", method = RequestMethod.GET)
	public void listPage(@ModelAttribute("scri") SearchCriteria scri, Model model) throws Exception {
	 logger.info("get list search");
	 
	 List<FreeBoard> list = FS.listSearch(scri);
	 model.addAttribute("list", list);
	 
	 PageMaker pageMaker = new PageMaker();
	 pageMaker.setCri(scri);
	 pageMaker.setTotalCount(FS.listCount());
	 //pageMaker.setTotalCount(FS.countSearch(scri));
	 model.addAttribute("pageMaker", pageMaker);
	}
	
}
