package kr.ac.kopo.yes.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.FreeBoard;
import kr.ac.kopo.yes.model.Goods;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

@Repository
public class GoodsDaoImpl implements GoodsDao {
	@Autowired
	SqlSession sql;
	
	@Override
	public List<Goods> list() {
		// TODO Auto-generated method stub
		return sql.selectList("goods.list");
	}

	@Override
	public void add(Goods item) {
		// TODO Auto-generated method stub
		sql.insert("goods.add",item);
	}

	@Override
	public void fileadd(String saveFile) {
		// TODO Auto-generated method stub
		sql.insert("fileupload.gdfileadd",saveFile);
	}

	@Override
	public Goods item(int goods_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("goods.item",goods_num);
	}

	@Override
	public List<FileUpload> filevi(int goods_num) {
		// TODO Auto-generated method stub
		return sql.selectList("fileupload.gdfilelist",goods_num);
	}

	@Override
	public void filedelete(String file_name) {
		// TODO Auto-generated method stub
		sql.delete("fileupload.filedelete",file_name);
	}

	@Override
	public void update(Goods item) {
		// TODO Auto-generated method stub
		sql.update("goods.update",item);
	}

	@Override
	public void fileupdate(FileUpload fileup) {
		// TODO Auto-generated method stub
		sql.insert("fileupload.gdfileup",fileup);
	}

	@Override
	public void delete(int goods_num) {
		// TODO Auto-generated method stub
		sql.delete("goods.delete",goods_num);
	}

	@Override
	public void incView(int goods_num) {
		// TODO Auto-generated method stub
		sql.update("goods.incView",goods_num);
	}

	@Override
	public List<Reply> replyList(int reply_num) {
		// TODO Auto-generated method stub
		return sql.selectList("goods.replylist", reply_num);
	}

	@Override
	public void like(int goods_num) {
		// TODO Auto-generated method stub
		sql.update("goods.like", goods_num);
	}

	@Override
	public void addReply(Reply reply) {
		// TODO Auto-generated method stub
		sql.insert("goods.add_reply",reply);
	}

	@Override
	public String idCheck(int reply_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("reply.replyUserIdCheck", reply_num);
	}

	@Override
	public void deleteReply(Reply reply) {
		// TODO Auto-generated method stub
		sql.delete("reply.deleteReply",reply);
	}

	@Override
	public List<Goods> listPage(Criteria cri) {
		// TODO Auto-generated method stub
		return sql.selectList("goods.listPage",cri);
	}

	@Override
	public int listCount() {
		// TODO Auto-generated method stub
		return sql.selectOne("goods.listCount");
	}

	@Override
	public List<Goods> listSearch(SearchCriteria scri) {
		// TODO Auto-generated method stub
		return sql.selectList("goods.listSearch",scri);
	}

	@Override
	public Product provi(int goods_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("goods.items",goods_num);
	}

}
