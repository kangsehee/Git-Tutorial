package kr.ac.kopo.yes.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.PageMaker;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;
import kr.ac.kopo.yes.model.User;
import kr.ac.kopo.yes.service.ProductService;

@Controller
@RequestMapping(value="/Product")
public class ProductController {

	
		final String path = "Product/";
		ArrayList<String> list;
		
		private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
		
		@Autowired
		ProductService PS; // FreeBoardService FS; = new FreeBoardService();

		
		/**
		 * �뜝�럩�겱�뜝�럩占썽뇦猿딆뒩占쎈뻣�뜝�럥�냷 嶺뚮ㅄ維뽨빳占�
		 * @param model
		 * @return
		 */
		//상품리스트
		@RequestMapping(value="/list")
		String list(Model model) {
			List<Product> list = PS.list();
			model.addAttribute("list", list);
		
			return path+"list";
		}
		


		/**
		 * �뜝�럩�겱�뜝�럩占썽뇦猿딆뒩占쎈뻣�뜝�럥�냷 �뜝�럥苡삣슖�댙�삕 �뜝�럥夷�
		 * @param locale
		 * @param model
		 * @return
		 */
		
		
		@RequestMapping(value="/add", method=RequestMethod.GET)
		String add(Locale locale, Model model) {
			
			return path+"add";
		}

		//상품추가하기
				@RequestMapping(value="/add", method=RequestMethod.POST)
				public String add(HttpSession session, MultipartHttpServletRequest mtfRequest,Product item) throws Exception {
					//외래키아이디가져옴
					item.setId((String) session.getAttribute("user"));
					
					
					//파일업로드부분
					 MultipartFile mf = mtfRequest.getFile("file");			
					String path = "C:\\images\\imgUpload\\";
			 
				   
				            String originFileName = mf.getOriginalFilename(); //최초파일이름
				            long fileSize = mf.getSize();//파일크기
				            
				            System.out.println("originFileName : " + originFileName);
				            System.out.println("fileSize : " + fileSize);
				            
				            String saveFile = System.currentTimeMillis() +originFileName;
				            
				            String safeFile = path + System.currentTimeMillis() + originFileName;
				            try {
				                mf.transferTo(new File(safeFile));
				            } catch (IllegalStateException e) {
				                // TODO Auto-generated catch block
				                e.printStackTrace();
				            } catch (IOException e) {
				                // TODO Auto-generated catch block
				                e.printStackTrace();
				            }
				            item.setPd_img(saveFile);
				            
				            PS.add(item);
				        
				        return "redirect:list";
				}
	/*	//상품추가하기
		@RequestMapping(value="/add", method=RequestMethod.POST)
		public String add(HttpSession session, MultipartHttpServletRequest mtfRequest,Product item,FileUpload fileup) throws Exception {
			//외래키아이디가져옴
			item.setId((String) session.getAttribute("user"));
			
			PS.add(item);
			//파일업로드부분
			List<MultipartFile> fileList = mtfRequest.getFiles("file");				
			String path = "C:\\images\\imgUpload\\";
	 
		        for (MultipartFile mf : fileList) {
		            String originFileName = mf.getOriginalFilename(); //최초파일이름
		            long fileSize = mf.getSize();//파일크기
		            
		            System.out.println("originFileName : " + originFileName);
		            System.out.println("fileSize : " + fileSize);
		            
		            String saveFile = System.currentTimeMillis() +originFileName;
		            
		            String safeFile = path + System.currentTimeMillis() + originFileName;
		           // String safeFile = path + System.currentTimeMillis() + originFileName;
		            try {
		                mf.transferTo(new File(safeFile));
		            } catch (IllegalStateException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            } catch (IOException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            PS.fileadd(saveFile);
		        }
		        
		        return "redirect:list";
		}
	*/
		@RequestMapping(value="/update", method=RequestMethod.GET)
		String update(int goods_num, Model model){
			
		Product item = PS.item(goods_num);
		model.addAttribute("item",item);

			return path+"update";
		}
		
		//상품 수정 및 사진추가
		@RequestMapping(value="/update", method=RequestMethod.POST)
		String update(MultipartHttpServletRequest mtfRequest,Product item) throws Exception{
			PS.update(item);
			
			//파일업로드부분
			 MultipartFile mf = mtfRequest.getFile("file");			
			String path = "C:\\images\\imgUpload\\";
	 
		   
		            String originFileName = mf.getOriginalFilename(); //최초파일이름
		            long fileSize = mf.getSize();//파일크기
		            
		            System.out.println("originFileName : " + originFileName);
		            System.out.println("fileSize : " + fileSize);
		            
		            String saveFile = System.currentTimeMillis() +originFileName;
		            
		            String safeFile = path + System.currentTimeMillis() + originFileName;
		           // String safeFile = path + System.currentTimeMillis() + originFileName;
		            try {
		                mf.transferTo(new File(safeFile));
		            } catch (IllegalStateException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            } catch (IOException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            item.setPd_img(saveFile);
		            
		            PS.update(item);

			
			return "redirect:list";
		}	
		//상품삭제
		@RequestMapping("/delete")
		String delete(int pd_num) {
			
			
			PS.delete(pd_num);

			return "redirect:list";
		}

		
		//상세정보보여줌
		@RequestMapping(value="/view")
		String view(int pd_num, Model model) {

			//상품상세정보
			Product item = PS.item(pd_num);
			model.addAttribute("item", item);
			
			return path + "view";
		}

		// 상품리스트&페이징
		@RequestMapping(value = "/listPage", method = RequestMethod.GET)
		public void listPage(Criteria cri, Model model) throws Exception {
		 logger.info("get list search");
		 
		 List<Product> list = PS.listPage(cri);
		 model.addAttribute("list", list);
		
		 PageMaker pageMaker = new PageMaker();
		 pageMaker.setCri(cri);
		 pageMaker.setTotalCount(PS.listCount());
		 model.addAttribute("pageMaker", pageMaker);
		}
		
		// 상품리스트&검색&페이징
		@RequestMapping(value = "/listSearch", method = RequestMethod.GET)
		public void listPage(@ModelAttribute("scri") SearchCriteria scri, Model model) throws Exception {
		 logger.info("get list search");
		 
		 List<Product> list = PS.listSearch(scri);
		 model.addAttribute("list", list);
		 
		 PageMaker pageMaker = new PageMaker();
		 pageMaker.setCri(scri);
		 pageMaker.setTotalCount(PS.listCount());
		 //pageMaker.setTotalCount(FS.countSearch(scri));
		 model.addAttribute("pageMaker", pageMaker);
		}
		
	}

