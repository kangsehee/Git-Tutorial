package kr.ac.kopo.yes.dao;

import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.mail.HtmlEmail;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import kr.ac.kopo.yes.model.User;

@Repository
public class UserDaoImpl implements UserDao {
	@Autowired
	SqlSession sql;

	private static String namespace = "user";
//�α���
	@Override
	public boolean login(User user) {
		// TODO Auto-generated method stub
		if (sql.selectOne("user.login", user) == null) {
			return false;
		} else {
			return true;
		}
	}
	//ȸ�����
	@Override
	public User item(String id) {
		// TODO Auto-generated method stub
		System.out.println(id);
		return sql.selectOne("user.item", id);
	}
//ȸ�����
	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return sql.selectList("user.list");
	}

	/*@Override
	public void add(User item) {
		// TODO Auto-generated method stub
		sql.insert("user.add", item);
	}*/
//ȸ������
	@Override
	public void update(User item) {
		// TODO Auto-generated method stub
		sql.update("user.update", item);
	}
//ȸ��Ż��
	@Override
	public void delete(String id) {
		// TODO Auto-generated method stub
		sql.delete("user.delete", id);
	}
	@Override
	public int join_member(User item) {
		// TODO Auto-generated method stub
		return sql.insert("user.join_member", item);
	}
/*
	@Override
	public int approval_member(User member) throws Exception {
		return sql.update("user.approval_member", member);
	}
*/
	// ���̵� ã��
	@Override
	public String find_id(String email) throws Exception {
		return sql.selectOne("user.find_id", email);
	}
	
	// ���̵� �ߺ� �˻�
			@Override
			public int check_id(String id) throws Exception{
				// TODO Auto-generated method stub
				return sql.selectOne("user.check_id", id);
			}
		// �̸��� �ߺ� �˻�
				@Override
				public int check_email(String email) throws Exception{
					// TODO Auto-generated method stub
					return sql.selectOne("user.check_email", email);
				}
//��й�ȣ����
	@Override
	public int update_pw(User member) {
		// TODO Auto-generated method stub
		return sql.update("user.update_pw", member);
	}



}
