package kr.ac.kopo.yes.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.ac.kopo.yes.model.User;
import kr.ac.kopo.yes.service.UserService;

@Controller
@RequestMapping("/")
public class RootController {

	@Autowired
	UserService US;
	
	@RequestMapping(value="/")
	public String index() {
		return "index";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	String login() {
		return"login";
	}
	@RequestMapping(value="/login", method=RequestMethod.POST)
	String login(User user,HttpSession session) {
		
		if(US.login(user)) {
			session.setAttribute("user", user.getId());
			String id=user.getId();
			User item = US.item(id);
			session.setAttribute("name", item.getName());
			System.out.println("로그인성공");
		}else {
			System.out.println("로그인실패");
		}
		return "redirect:.";
	}
	
	@RequestMapping("/logout")
	String logout(HttpSession session) {
		session.invalidate();
		System.out.println("로그아웃");
		return "redirect:.";
	}
	
	@RequestMapping("/user")
	String user() {
		return "user";
	}
}
