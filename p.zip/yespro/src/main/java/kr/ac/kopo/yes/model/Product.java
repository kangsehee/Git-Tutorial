package kr.ac.kopo.yes.model;

import java.util.Date;

public class Product {

	int pd_num;
	String pd_name;
	String pd_img;
	Date pd_enr_date;
	int pd_beg_price;
	int pd_quantity;
	int pd_hop_price;
	String pd_beg_date;
	String id;
	int goods_num;
	
	
	public int getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(int goods_num) {
		this.goods_num = goods_num;
	}
	public int getPd_num() {
		return pd_num;
	}
	public void setPd_num(int pd_num) {
		this.pd_num = pd_num;
	}
	public String getPd_name() {
		return pd_name;
	}
	public void setPd_name(String pd_name) {
		this.pd_name = pd_name;
	}
	public String getPd_img() {
		return pd_img;
	}
	public void setPd_img(String pd_img) {
		this.pd_img = pd_img;
	}
	public Date getPd_enr_date() {
		return pd_enr_date;
	}
	public void setPd_enr_date(Date pd_err_date) {
		this.pd_enr_date = pd_err_date;
	}
	public int getPd_beg_price() {
		return pd_beg_price;
	}
	public void setPd_beg_price(int pd_beg_price) {
		this.pd_beg_price = pd_beg_price;
	}
	public int getPd_quantity() {
		return pd_quantity;
	}
	public void setPd_quantity(int pd_quantity) {
		this.pd_quantity = pd_quantity;
	}
	public int getPd_hop_price() {
		return pd_hop_price;
	}
	public void setPd_hop_price(int pd_hop_price) {
		this.pd_hop_price = pd_hop_price;
	}
	public String getPd_beg_date() {
		return pd_beg_date;
	}
	public void setPd_beg_date(String pd_beg_date) {
		this.pd_beg_date = pd_beg_date;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	

}
