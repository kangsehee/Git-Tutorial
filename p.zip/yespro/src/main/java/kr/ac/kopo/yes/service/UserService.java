package kr.ac.kopo.yes.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import kr.ac.kopo.yes.model.User;

public interface UserService {

	boolean login(User user);

	User item(String id);

	List<User> list();

	//void add(User item) throws Exception;

	void update(User item);

	void delete(String id);

	User findAccount(String email);

	String find_id(HttpServletResponse response, String email) throws Exception;

	String create_key() throws Exception;

	void send_mail(User member) throws Exception;

	void find_pw(HttpServletResponse response, User member) throws Exception;

	int join_member(User user, HttpServletResponse response) throws Exception;




}
