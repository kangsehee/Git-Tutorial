package kr.ac.kopo.yes.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.ac.kopo.yes.model.User;
import kr.ac.kopo.yes.service.UserService;

@Controller
@RequestMapping("/user/*")
public class UserController {
	final String path = "user/";

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	UserService US;

	@RequestMapping("/")
	String admin() {

		return "user";
	}

	@RequestMapping("/list")
	String list(Model model) {
		List<User> list = US.list();

		model.addAttribute("list", list);
		return path + "list";
	}

	/*@RequestMapping(value = "/add", method = RequestMethod.GET)
	String add() {
		return path + "add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	String add(User item) throws Exception {
		US.add(item);

		return "redirect:/";
	}*/

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	String update(String id, Model model) {
		User item = US.item(id);

		model.addAttribute("item", item);
		return path + "update";
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	String update(User item) {
		US.update(item);
		return "redirect:list";
	}

	@RequestMapping("/delete")
	String delete(String id) {
		US.delete(id);
		return "redirect:list";
	}

/*	@RequestMapping(value = "/checkId", method = RequestMethod.POST)
	@ResponseBody
	public int postCheckId(HttpServletRequest req) throws Exception {
		logger.info("post checkId");

		String id = req.getParameter("id");
		User checkId = US.checkId(id);

		int result = 0;

		if (checkId != null) {
			result = 1;
		}
		return result;

	}

//�̸��� �ߺ� �˻�(AJAX)
	@RequestMapping(value = "/checkEmail", method = RequestMethod.POST)
	@ResponseBody
	public int postCheckEmail(HttpServletRequest req) throws Exception {
		logger.info("post check_email");

		String email = req.getParameter("email");
		User checkEmail = US.checkEmail(email);

		int eresult = 0;

		if (checkEmail != null) {
			eresult = 1;
		}
		return eresult;
	}*/

	//ȸ�� ���� �� �̵�
	//�� ������ /user/memberJoinForm. do�� ��û�� ������ /user/memberJoinForm.jsp ������ �������ִ� ����
		@RequestMapping(value = "/memberJoinForm.do")
		public String memberJoinForm() throws Exception{
			return "/user/memberJoinForm";
		}

		//ȸ�� ����
		@RequestMapping(value = "/join_member.do", method = RequestMethod.POST)
		public String join_member(@ModelAttribute User user, RedirectAttributes rttr, HttpServletResponse response,String div) throws Exception{
			rttr.addFlashAttribute("result", US.join_member(user, response));
			return "redirect:/";
		}
		
	// ��й�ȣ ã�� ��
	@RequestMapping(value = "/find_pw_form.do")
	public String find_pw_form() throws Exception {
		return "/user/find/find_pw_form";
	}

	// ���̵� ã�� ��
	@RequestMapping(value = "/find_id_form.do")
	public String find_id_form() throws Exception {
		return "/user/find/find_id_form";
	}

	// ���̵� ã��
	@RequestMapping(value = "/find_id.do", method = RequestMethod.POST)
	public String find_id(HttpServletResponse response, @RequestParam("email") String email, Model md)
			throws Exception {
		md.addAttribute("id", US.find_id(response, email));
		return "/user/find/find_id";
	}

	// ��й�ȣ ã��
	@RequestMapping(value = "/find_pw.do", method = RequestMethod.POST)
	public void find_pw(@ModelAttribute User member, HttpServletResponse response) throws Exception {
		US.find_pw(response, member);
	}
}
