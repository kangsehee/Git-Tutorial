package kr.ac.kopo.yes.service;

import java.util.List;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Goods;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

public interface GoodsService {

	List<Goods> list();

	void add(Goods item);

	void fileadd(String saveFile);

	Goods item(int goods_num);

	List<FileUpload> filevi(int goods_num);

	void filedelete(String fileName);

	void update(Goods item);

	void fileupdate(FileUpload fileup);

	void delete(int goods_num);

	void incView(int goods_num);

	List<Reply> replyList(int reply_num);

	void like(int goods_num);

	void addReply(Reply reply);

	String idCheck(int reply_num);

	void deleteReply(Reply reply);

	List<Goods> listPage(Criteria cri);

	int listCount();

	List<Goods> listSearch(SearchCriteria scri);

	Product provi(int goods_num);


}
