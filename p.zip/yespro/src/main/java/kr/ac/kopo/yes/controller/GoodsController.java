package kr.ac.kopo.yes.controller;



import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import java.util.List;
import java.util.Locale;


import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;


import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Goods;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.User;
import kr.ac.kopo.yes.service.GoodsService;
import kr.ac.kopo.yes.service.ProductService;

@Controller
@RequestMapping(value= "/Goods")
public class GoodsController {
	final String path = "Goods/";
	ArrayList<String> list;
	
	
	private static final Logger logger = LoggerFactory.getLogger(GoodsController.class);
	
	@Autowired
	GoodsService GS; // FreeBoardService FS; = new FreeBoardService();
	
	@Autowired
	ProductService PS; 
	
	//final String uploadPath = "D:\\images";
	/*@Resource(name = "uploadPath")
	private String uploadPath;
	*/
	/**
	 * �옄�쑀寃뚯떆�뙋 紐⑸줉
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/list")
	String list(Model model) {
		
		List<Product> list = PS.list();
		model.addAttribute("list", list);

		return path+"list";
	}
	


	/**
	 * �옄�쑀寃뚯떆�뙋 �벑濡� �뤌
	 * @param locale
	 * @param model
	 * @return
	 */
	
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	String add(Locale locale, Model model) {
		
		return path+"add";
	}

	
	//게시글올리기 & 파일업로드
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String add(HttpSession session, MultipartHttpServletRequest mtfRequest,Goods item,FileUpload fileup,Product items) throws Exception {
		//외래키아이디가져옴
		items.setId((String) session.getAttribute("user"));
		
		//글관련
				GS.add(item);
				//글관련사진올리기
				List<MultipartFile> fileList = mtfRequest.getFiles("files");	
				String path = "C:\\images\\imgUpload\\";
		 
			        for (MultipartFile mfs : fileList) {
			            String originFileNames = mfs.getOriginalFilename(); // 원본파일명
			            long fileSizes = mfs.getSize(); // 파일 사이즈
			            
			            System.out.println("originFileName : " + originFileNames);
			            System.out.println("fileSize : " + fileSizes);
			            //String saveFile =originFileName;
			            
			            String saveFiles = System.currentTimeMillis() +originFileNames;
			            
			            String safeFiles = path + System.currentTimeMillis() + originFileNames;
			            try {
			                mfs.transferTo(new File(safeFiles));
			            } catch (IllegalStateException e) {
			                // TODO Auto-generated catch block
			                e.printStackTrace();
			            } catch (IOException e) {
			                // TODO Auto-generated catch block
			                e.printStackTrace();
			            }
			            GS.fileadd(saveFiles);
			        }
			        
		//상품관련
		 MultipartFile mf = mtfRequest.getFile("file");			
	

	   
	            String originFileName = mf.getOriginalFilename(); //최초파일이름
	            long fileSize = mf.getSize();//파일크기
	            
	            System.out.println("originFileName : " + originFileName);
	            System.out.println("fileSize : " + fileSize);
	            
	            String saveFile = System.currentTimeMillis() +originFileName;
	            
	            String safeFile = path + System.currentTimeMillis() + originFileName;
	            try {
	                mf.transferTo(new File(safeFile));
	            } catch (IllegalStateException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            } catch (IOException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	            items.setPd_img(saveFile);
	            
	            PS.add(items);
		
		
		
	        
	        return "redirect:list";
	}
	//변경
	@RequestMapping(value="/update", method=RequestMethod.GET)
	String update(int goods_num, Model model){
		
	Goods items = GS.item(goods_num);
	model.addAttribute("items",items);
	
	Product item = PS.gitem(goods_num);
	model.addAttribute("item",item);
	//사진보여주기
		List<FileUpload> filevi = GS.filevi(goods_num);
		model.addAttribute("filevi", filevi);
			
		return path+"update";
	}
	//변경
	@RequestMapping("/deleteFile")
	String deleteFile(String fileName,int goods_num) {
		
		
		GS.filedelete(fileName);

		return "redirect:update?goods_num=" + goods_num;
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	String update(MultipartHttpServletRequest mtfRequest,Goods items,FileUpload fileup,int goods_num,Product item) throws Exception{
		
		
		//썸네일부분
		 MultipartFile mf = mtfRequest.getFile("file");			
			String path = "C:\\images\\imgUpload\\";
	 
		   
		            String originFileName = mf.getOriginalFilename(); //최초파일이름
		            long fileSize = mf.getSize();//파일크기
		            
		            System.out.println("originFileName : " + originFileName);
		            System.out.println("fileSize : " + fileSize);
		            
		            String saveFile = System.currentTimeMillis() +originFileName;
		            
		            String safeFile = path + System.currentTimeMillis() + originFileName;
		            try {
		                mf.transferTo(new File(safeFile));
		            } catch (IllegalStateException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            } catch (IOException e) {
		                // TODO Auto-generated catch block
		                e.printStackTrace();
		            }
		            item.setPd_img(saveFile);
		            
		            PS.update(item);
		
		//다중파일부분
		logger.info(goods_num+"goods_num");
		List<MultipartFile> fileList = mtfRequest.getFiles("files");

	        
		for (MultipartFile mfs : fileList) {
            String originFileNames = mfs.getOriginalFilename(); // 원본파일명
            long fileSizes = mfs.getSize(); // 파일 사이즈
            
            System.out.println("originFileName : " + originFileNames);
            System.out.println("fileSize : " + fileSizes);

            String saveFiles = System.currentTimeMillis() +originFileNames;
            String safeFiles = path + System.currentTimeMillis() + originFileNames;
           System.out.println(saveFiles+"saveFile");
            // String safeFile = path + System.currentTimeMillis() + originFileName;
            try {
                mf.transferTo(new File(safeFiles));
            } catch (IllegalStateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            fileup.setGoods_num(goods_num);
            fileup.setFile_name(saveFiles);
            logger.info(saveFiles+"saveFile");
            GS.fileupdate(fileup);
        }
		GS.update(items);
		return "redirect:list";
	}	
	
	@RequestMapping("/delete")
	String delete(int goods_num) {
		
		PS.gdelete(goods_num);
		GS.delete(goods_num);

		return "redirect:list";
	}

	
	//게시글
	@RequestMapping(value="/view")
	String view(int goods_num, Model model) {
		//조회수
		GS.incView(goods_num);
		/*FileUpload filevi = FUS.filevi(fb_num);
		model.addAttribute("filelist", filevi);
		*/
		
		//게시글보여주기 관련 굿즈페이지
		Goods item = GS.item(goods_num);
		model.addAttribute("item", item);
		
		//게시글보여주기 관련 상품정보
		Product pro = GS.provi(goods_num);
		model.addAttribute("pro", pro);
		//사진보여주기
		List<FileUpload> filevi = GS.filevi(goods_num);
		model.addAttribute("filevi", filevi);
				
		
		List<Reply> reply = GS.replyList(goods_num);
		model.addAttribute("reply", reply);
		
		return path + "view";
	}
	

	
	
//추천
	@RequestMapping("/like")
	String like(int goods_num) {
		GS.like(goods_num);
		return "redirect:list";
	}

	@ResponseBody
	@RequestMapping(value = "/view/replyList", method = RequestMethod.GET)
	public List<Reply> getReplyList(@RequestParam("n") int goods_num) throws Exception {
		logger.info("get reply list");
	 List<Reply> reply = GS.replyList(goods_num);
	 
	 return reply;
	} 
	//댓글추가
	@ResponseBody
	@RequestMapping(value="/view/addReply",method=RequestMethod.POST)
	public void addReply(Reply reply,HttpSession session) throws Exception{
		// logger.info("regist reply");
		
		reply.setId((String) session.getAttribute("user"));
		
		GS.addReply(reply);
		}

	// 댓글지우기
	@ResponseBody
	@RequestMapping(value = "/view/deleteReply", method = RequestMethod.POST)
	public int getReplyList(Reply reply,HttpSession session,User member) throws Exception {
	 logger.info("post delete reply");

	 int result = 0;
	 
	 member.setId((String)session.getAttribute("user"));
	   System.out.println(reply.getReply_num()+"<<<<<<<<<<<<getReply_num");
	 String replyId = GS.idCheck(reply.getReply_num());
	 
	 if(member.getId().equals(replyId)) {
	  
	  reply.setId(member.getId());
	  GS.deleteReply(reply);
	  
	  result = 1;
	 }
	 
	 return result; 
	}

	
}
