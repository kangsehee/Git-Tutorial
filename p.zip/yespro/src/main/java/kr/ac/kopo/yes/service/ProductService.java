package kr.ac.kopo.yes.service;

import java.util.List;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

public interface ProductService {

	List<Product> list();

	void add(Product item);

	void fileadd(String saveFile);

	Product gitem(int goods_num);

	Product item(int pd_num);
	
	void update(Product item);

	void filedelete(String file_name);

	void delete(int pd_num);

	List<Product> listPage(Criteria cri);

	int listCount();

	List<Product> listSearch(SearchCriteria scri);

	void gdelete(int goods_num);


}
