package kr.ac.kopo.yes.model;

public class FileUpload {
	String file_name;
	int fb_num;
	int goods_num;
	int gauction_num;
	int making_pd_num;
	int file_no;
	
	
	
	public int getFile_no() {
		return file_no;
	}
	public void setFile_no(int file_no) {
		this.file_no = file_no;
	}
	
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public int getFb_num() {
		return fb_num;
	}
	public void setFb_num(int fb_num) {
		this.fb_num = fb_num;
	}
	public int getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(int goods_num) {
		this.goods_num = goods_num;
	}
	public int getGauction_num() {
		return gauction_num;
	}
	public void setGauction_num(int gauction_num) {
		this.gauction_num = gauction_num;
	}
	public int getMaking_pd_num() {
		return making_pd_num;
	}
	public void setMaking_pd_num(int making_pd_num) {
		this.making_pd_num = making_pd_num;
	}

	
	
}
