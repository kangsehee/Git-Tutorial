package kr.ac.kopo.yes.dao;

import java.util.List;
import java.util.Map;

import kr.ac.kopo.yes.model.User;

public interface UserDao {

	boolean login(User user);

	User item(String id);

	List<User> list();

	void update(User item);

	void delete(String id);

	String find_id(String email) throws Exception;

	int check_email(String email) throws Exception;

	int update_pw(User member);

	int check_id(String id) throws Exception;

	int join_member(User user);


	

	

}
