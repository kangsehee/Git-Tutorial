package kr.ac.kopo.yes.model;

import java.util.Date;


public class FreeBoard {
	

	int fb_num;
	String id;
	String fb_title;
	String fb_contents;
	Date fb_date;
	int fb_ref;
	int fb_like;
	String thumb;

	
	
	public void setFb_like(int fb_like) {
		this.fb_like = fb_like;
	}
	public String getThumb() {
		return thumb;
	}
	public void setThumb(String thumb) {
		this.thumb = thumb;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getFb_num() {
		return fb_num;
	}
	public void setFb_num(int fb_num) {
		this.fb_num = fb_num;
	}
	public String getFb_title() {
		return fb_title;
	}
	public void setFb_title(String fb_title) {
		this.fb_title = fb_title;
	}
	public String getFb_contents() {
		return fb_contents;
	}
	public void setFb_contents(String fb_contents) {
		this.fb_contents = fb_contents;
	}
	public Date getFb_date() {
		return fb_date;
	}
	public void setFb_date(Date fb_date) {
		this.fb_date = fb_date;
	}
	public int getFb_ref() {
		return fb_ref;
	}
	public void setFb_ref(int fb_ref) {
		this.fb_ref = fb_ref;
	}
	public int getFb_like() {
		return fb_like;
	}
	public void setFd_like(int fb_like) {
		this.fb_like = fb_like;
	}
	


}
