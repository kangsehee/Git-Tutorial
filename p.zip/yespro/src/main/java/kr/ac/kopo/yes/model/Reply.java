package kr.ac.kopo.yes.model;

import java.util.Date;

public class Reply {
	
	int reply_num;
	String reply_contents;
	Date reply_date;
	String id;
	int fb_num;
	int making_pd_num;
	int goods_num;
	int gauction_num;
	
	public int getReply_num() {
		return reply_num;
	}
	public void setReply_num(int reply_num) {
		this.reply_num = reply_num;
	}
	public String getReply_contents() {
		return reply_contents;
	}
	public void setReply_contents(String reply_contents) {
		this.reply_contents = reply_contents;
	}
	public Date getReply_date() {
		return reply_date;
	}
	public void setReply_date(Date reply_date) {
		this.reply_date = reply_date;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public int getFb_num() {
		return fb_num;
	}
	public void setFb_num(int fb_num) {
		this.fb_num = fb_num;
	}
	public int getMaking_pd_num() {
		return making_pd_num;
	}
	public void setMaking_pd_num(int making_pd_num) {
		this.making_pd_num = making_pd_num;
	}
	public int getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(int goods_num) {
		this.goods_num = goods_num;
	}
	public int getGauction_num() {
		return gauction_num;
	}
	public void setGauction_num(int gauction_num) {
		this.gauction_num = gauction_num;
	}
	
	
	
}
