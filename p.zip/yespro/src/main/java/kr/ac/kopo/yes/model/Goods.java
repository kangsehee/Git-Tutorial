package kr.ac.kopo.yes.model;

public class Goods {
	int goods_num;
	int goods_ref;
	int goods_views;
	String goods_contents;

	public int getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(int goods_num) {
		this.goods_num = goods_num;
	}
	public int getGoods_ref() {
		return goods_ref;
	}
	public void setGoods_ref(int goods_ref) {
		this.goods_ref = goods_ref;
	}
	public int getGoods_views() {
		return goods_views;
	}
	public void setGoods_views(int goods_views) {
		this.goods_views = goods_views;
	}
	public String getGoods_contents() {
		return goods_contents;
	}
	public void setGoods_contents(String goods_contents) {
		this.goods_contents = goods_contents;
	}

	
	
}
