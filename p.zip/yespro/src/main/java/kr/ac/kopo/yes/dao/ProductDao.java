package kr.ac.kopo.yes.dao;

import java.util.List;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

public interface ProductDao {

	List<Product> list();

	void add(Product item);

	void fileadd(String saveFile);

	void filedelete(String fileName);

	void update(Product item);

	Product gitem(int goods_num);
	
	Product item(int pd_num);

	void delete(int pd_num);

	List<Product> listPage(Criteria cri);

	int listCount();

	List<Product> listSearch(SearchCriteria scri);

	void gdelete(int goods_num);

}
