package kr.ac.kopo.yes.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;
@Repository
public class ProductDaoImpl implements ProductDao {
@Autowired
SqlSession sql;

	@Override
	public List<Product> list() {
		return sql.selectList("product.list");
	}

	@Override
	public void add(Product item) {
		sql.insert("product.add",item);
	}

	@Override
	public void fileadd(String saveFile) {
		// TODO Auto-generated method stub
		sql.insert("fileupload.fbfileadd",saveFile);
	}

	@Override
	public void filedelete(String fileName) {
		// TODO Auto-generated method stub
		sql.delete("fileupload.filedelete",fileName);
	}

	@Override
	public void update(Product item) {
		// TODO Auto-generated method stub
		sql.update("product.update",item);
	}


	@Override
	public void delete(int pd_num) {
		// TODO Auto-generated method stub
		sql.delete("product.delete",pd_num);
	}

	@Override
	public List<Product> listPage(Criteria cri) {
		// TODO Auto-generated method stub
		return sql.selectList("product.listPage",cri);
	}

	@Override
	public int listCount() {
		// TODO Auto-generated method stub
		return sql.selectOne("product.listCount");
	}

	@Override
	public List<Product> listSearch(SearchCriteria scri) {
		// TODO Auto-generated method stub
		return sql.selectList("product.listSearch",scri);
	}
	@Override
	public Product item(int pd_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("product.item",pd_num);
	}
	@Override
	public Product gitem(int goods_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("product.gitem",goods_num);
	}

	@Override
	public void gdelete(int goods_num) {
		// TODO Auto-generated method stub
		sql.delete("product.gdelete",goods_num);
	}

}
