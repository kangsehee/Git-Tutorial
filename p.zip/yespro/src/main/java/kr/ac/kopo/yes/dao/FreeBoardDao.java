package kr.ac.kopo.yes.dao;


import java.util.List;


import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.FreeBoard;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

public interface FreeBoardDao {
	
	List<FreeBoard> list();
	
	FreeBoard item(int fb_num);
		
	void delete(int fb_num);
	
	void like(int fb_num);
	
	void incView(int fb_num);

	void addReply(Reply reply);

	List<Reply> replyList(int fb_num);

	String idCheck(int reply_num);

	void deleteReply(Reply reply);

	List<FreeBoard> listPage(Criteria cri);

	int listCount();

	List<FreeBoard> listSearch(SearchCriteria scri);

	int countSearch(SearchCriteria scri);

	List<FileUpload> filevi(int fb_num);

	void update(FreeBoard item);

	void add(FreeBoard item);

	void fileadd(String saveFile);

	//void fileupdate(String saveFile);

//	void filedelete(int fb_num);

	void filedelete(String file_name);

	//void fileupdate(String saveFile);

	void fileupdate(FileUpload fileup);

}
