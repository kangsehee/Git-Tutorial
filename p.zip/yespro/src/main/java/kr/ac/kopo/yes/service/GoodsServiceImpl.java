package kr.ac.kopo.yes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.yes.dao.GoodsDao;
import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Goods;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

@Service
public class GoodsServiceImpl implements GoodsService {
	@Autowired
	GoodsDao GD;
	
	@Override
	public List<Goods> list() {
		// TODO Auto-generated method stub
		return GD.list();
	}

	@Override
	public void add(Goods item) {
		// TODO Auto-generated method stub
		GD.add(item);
	}

	@Override
	public void fileadd(String saveFile) {
		// TODO Auto-generated method stub
		GD.fileadd(saveFile);
	}

	@Override
	public Goods item(int goods_num) {
		// TODO Auto-generated method stub
		return GD.item(goods_num);
	}

	@Override
	public List<FileUpload> filevi(int goods_num) {
		// TODO Auto-generated method stub
		return GD.filevi(goods_num);
	}

	@Override
	public void filedelete(String file_name) {
		// TODO Auto-generated method stub
		GD.filedelete(file_name);
	}

	@Override
	public void update(Goods item) {
		// TODO Auto-generated method stub
		GD.update(item);
	}

	@Override
	public void fileupdate(FileUpload fileup) {
		// TODO Auto-generated method stub
		GD.fileupdate(fileup);
	}

	@Override
	public void delete(int goods_num) {
		// TODO Auto-generated method stub
		GD.delete(goods_num);
	}

	@Override
	public void incView(int goods_num) {
		// TODO Auto-generated method stub
		GD.incView(goods_num);
	}

	@Override
	public List<Reply> replyList(int goods_num) {
		// TODO Auto-generated method stub
		return GD.replyList(goods_num);
	}

	@Override
	public void like(int goods_num) {
		// TODO Auto-generated method stub
		GD.like(goods_num);
	}

	@Override
	public void addReply(Reply reply) {
		// TODO Auto-generated method stub
		GD.addReply(reply);
	}

	@Override
	public String idCheck(int reply_num) {
		// TODO Auto-generated method stub
		return GD.idCheck(reply_num);
	}

	@Override
	public void deleteReply(Reply reply) {
		// TODO Auto-generated method stub
		GD.deleteReply(reply);
	}

	@Override
	public List<Goods> listPage(Criteria cri) {
		// TODO Auto-generated method stub
		return GD.listPage(cri);
	}

	@Override
	public int listCount() {
		// TODO Auto-generated method stub
		return GD.listCount();
	}

	@Override
	public List<Goods> listSearch(SearchCriteria scri) {
		// TODO Auto-generated method stub
		return GD.listSearch(scri);
	}

	@Override
	public Product provi(int goods_num) {
		// TODO Auto-generated method stub
		return GD.provi(goods_num);
	}

}
