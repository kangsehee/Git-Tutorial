package kr.ac.kopo.yes.dao;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.FreeBoard;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;
@Repository
public class FreeBoardDaoImpl implements FreeBoardDao {
@Autowired
SqlSession sql;

	@Override
	public List<FreeBoard> list() {
		// TODO Auto-generated method stub
		return sql.selectList("freeboard.list");
	}

	//게시판 view보여쥼
	@Override
	public FreeBoard item(int fb_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("freeboard.item",fb_num);
	}


	@Override
	public void delete(int fb_num) {
		// TODO Auto-generated method stub
		sql.delete("freeboard.delete", fb_num);
	}

/*	@Override
	public void filedelete(int fb_num) {
		// TODO Auto-generated method stub
		sql.delete("fileupload.fbfiledelete",fb_num);
	}
*/

	@Override
	public void like(int fb_num) {
		// TODO Auto-generated method stub
		sql.update("freeboard.like", fb_num);
	}

	@Override
	public void incView(int fb_num) {
		// TODO Auto-generated method stub
		sql.update("freeboard.incView", fb_num);
	}


	@Override
	public void addReply(Reply reply) {
		// TODO Auto-generated method stub
		sql.insert("freeboard.add_reply",reply);
	}


	@Override
	public List<Reply> replyList(int reply_num) {
		// TODO Auto-generated method stub
		return sql.selectList("freeboard.replylist", reply_num);
	}


	@Override
	public String idCheck(int reply_num) {
		// TODO Auto-generated method stub
		return sql.selectOne("reply.replyUserIdCheck", reply_num);
	}


	@Override
	public void deleteReply(Reply reply) {
		// TODO Auto-generated method stub
		sql.delete("reply.deleteReply",reply);
	}


	@Override
	public List<FreeBoard> listPage(Criteria cri) {
		// TODO Auto-generated method stub
		return sql.selectList("freeboard.listPage",cri);
	}


	@Override
	public int listCount() {
		// TODO Auto-generated method stub
		return sql.selectOne("freeboard.listCount");
	}


	@Override
	public List<FreeBoard> listSearch(SearchCriteria scri) {
		// TODO Auto-generated method stub
		return sql.selectList("freeboard.listSearch",scri);
	}


	@Override
	public int countSearch(SearchCriteria scri) {
		// TODO Auto-generated method stub
		return sql.selectOne("freeboard.countSearch",scri);
	}

//사진보여줌
	@Override
	public List<FileUpload> filevi(int fb_num) {
		// TODO Auto-generated method stub
		return sql.selectList("fileupload.fbfilelist",fb_num);
	}




	@Override
	public void update(FreeBoard item) {
		// TODO Auto-generated method stub
		sql.update("freeboard.update",item);	
	}


	@Override
	public void add(FreeBoard item) {
		// TODO Auto-generated method stub
		sql.insert("freeboard.add",item);
	}



	@Override
	public void fileadd(String saveFile) {
		// TODO Auto-generated method stub
		sql.insert("fileupload.fbfileadd",saveFile);
	}


	/*@Override
	public void fileupdate(String saveFile) {
		// TODO Auto-generated method stub
		sql.insert("fileupload.fbfileup",saveFile);
	}*/


	@Override
	public void filedelete(String file_name) {
		// TODO Auto-generated method stub
		sql.delete("fileupload.filedelete",file_name);
	}

	@Override
	public void fileupdate(FileUpload fileup) {
		// TODO Auto-generated method stub
		sql.insert("fileupload.fbfileup",fileup);
	}

	




}
