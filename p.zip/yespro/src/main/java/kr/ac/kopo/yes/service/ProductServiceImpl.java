package kr.ac.kopo.yes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.yes.dao.ProductDao;
import kr.ac.kopo.yes.model.Criteria;
import kr.ac.kopo.yes.model.FileUpload;
import kr.ac.kopo.yes.model.Product;
import kr.ac.kopo.yes.model.Reply;
import kr.ac.kopo.yes.model.SearchCriteria;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao PD;
	
	@Override
	public List<Product> list() {
		// TODO Auto-generated method stub
		return PD.list();
	}

	@Override
	public void add(Product item) {
		// TODO Auto-generated method stub
		PD.add(item);
	}
	

	@Override
	public void fileadd(String saveFile) {
		// TODO Auto-generated method stub
		PD.fileadd(saveFile);
	}

	@Override
	public Product gitem(int goods_num) {
		// TODO Auto-generated method stub
		return PD.gitem(goods_num);
	}
	
	@Override
	public Product item(int pd_num) {
		// TODO Auto-generated method stub
		return PD.item(pd_num);
	}

	@Override
	public void update(Product item) {
		// TODO Auto-generated method stub
		PD.update(item);
	}

	@Override
	public void filedelete(String fileName) {
		// TODO Auto-generated method stub
		PD.filedelete(fileName);
	}

	@Override
	public void delete(int pd_num) {
		// TODO Auto-generated method stub
		PD.delete(pd_num);
	}

	@Override
	public List<Product> listPage(Criteria cri) {
		// TODO Auto-generated method stub
		return PD.listPage(cri);
	}

	@Override
	public int listCount() {
		// TODO Auto-generated method stub
		return PD.listCount();
	}

	@Override
	public List<Product> listSearch(SearchCriteria scri) {
		// TODO Auto-generated method stub
		return PD.listSearch(scri);
	}

	@Override
	public void gdelete(int goods_num) {
		// TODO Auto-generated method stub
		PD.gdelete(goods_num);
	}

}
